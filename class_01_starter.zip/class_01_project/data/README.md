# Frozen Class 1 teaching data

These CSVs are a frozen teaching subset of Seattle Public Library checkout data, distributed via Duke University's AI Accelerator. Source: https://github.com/AI-for-Data-Analysis/ai-for-data-analysis.github.io/raw/refs/heads/main/files/seattle-public-library.zip

`monthly_checkout_totals.csv` is the unchanged monthly aggregate. The two title files are 5,000-row samples, not population totals; do not sum their checkouts as total system activity or add them to the monthly aggregate. Missing monthly class rows are not zeros. Inspect observed coverage before comparing years.

Retrieved (UTC): 2026-09-21. Sample method: pandas DataFrame.sample without replacement, 5000 rows per supplied title-level sample.

Learning design adapted from Duke University's AI Accelerator under CC BY 4.0: https://analytics-accelerator.colab.duke.edu/
Data source catalog: https://catalog.data.gov/dataset/checkouts-by-title
