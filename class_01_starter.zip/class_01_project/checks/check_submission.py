"""Class 1 structural smoke check. Run from the unzipped project root."""

import csv
from hashlib import sha256
import json
from pathlib import Path
import re
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
INPUTS = ("monthly_checkout_totals.csv", "digital_title_sample_5000.csv", "physical_title_sample_5000.csv")
PROMPTS = ("prompt_inventory", "prompt_rules", "prompt_fresh", "prompt_relationship", "prompt_analysis", "prompt_revision")
ANSWERS = ("evidence_inventory", "decision_source", "evidence_rules", "evidence_fresh", "evidence_relationship", "evidence_analysis", "evidence_revision", "reflection")
RESULTS = ("monthly_comparison.csv", "annual_checkouts.csv", "checkout_trend.png", "coverage_and_share.png")
COLUMNS = ("year", "physical_checkouts", "digital_checkouts", "months_observed", "months_with_both_classes")
MONTHLY_COLUMNS = ("year", "month", "physical_checkouts", "digital_checkouts", "both_classes_recorded")


def fail(message: str) -> None:
    raise SystemExit(message)


def require(relative: str) -> Path:
    path = ROOT / relative
    if not path.is_file():
        fail(f"Missing required file: {relative}")
    if path.stat().st_size == 0:
        fail(f"Required file is empty: {relative}")
    return path


def source_text(source) -> str:
    return "".join(source) if isinstance(source, list) else str(source)


def check_notebook(path: Path) -> None:
    try:
        notebook = json.loads(path.read_text(encoding="utf-8"))
        if notebook.get("nbformat") != 4 or not isinstance(notebook.get("cells"), list):
            fail("lab.ipynb is not a valid notebook structure")
        responses = {cell.get("id"): cell for cell in notebook["cells"] if isinstance(cell, dict)}
        for key in PROMPTS:
            cell = responses.get(key)
            if not cell or "student-prompt" not in cell.get("metadata", {}).get("tags", []):
                fail(f"Missing exact-prompt notebook cell: {key}")
            if not source_text(cell.get("source", "")).strip():
                fail(f"Fill exact-prompt notebook cell: {key}")
        for key in ANSWERS:
            cell = responses.get(key)
            if not cell or "student-answer" not in cell.get("metadata", {}).get("tags", []):
                fail(f"Missing observation/reflection notebook cell: {key}")
            if not source_text(cell.get("source", "")).strip():
                fail(f"Fill observation/reflection notebook cell: {key}")
        diagram = responses.get("preview_relationship")
        if not diagram or diagram.get("cell_type") != "markdown" or "student-diagram" not in diagram.get("metadata", {}).get("tags", []):
            fail("Missing Mermaid relationship Markdown cell: preview_relationship")
        source = source_text(diagram.get("source", ""))
        fenced = re.search(r"```mermaid[ \t]*\r?\n(.*?)\r?\n```", source, flags=re.IGNORECASE | re.DOTALL)
        if not fenced or not re.match(r"\s*erDiagram\b", fenced.group(1)):
            fail("Fill the Mermaid relationship cell with a fenced erDiagram and render it")
        body = fenced.group(1).lower()
        required = ("monthly", "digital", "physical", "checkout_year", "checkout_month", "checkoutyear", "checkoutmonth")
        if any(part not in body for part in required) or sum(".." in line or "--" in line for line in body.splitlines()) < 2:
            fail("Mermaid relationship cell must show the three data roles, real date headers, and two connections")
    except (UnicodeError, json.JSONDecodeError) as error:
        fail(f"Cannot read lab.ipynb as a notebook: {error}")


def check_table(path: Path) -> None:
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        if not set(COLUMNS).issubset(reader.fieldnames or []):
            fail("annual_checkouts.csv is missing required columns: " + ", ".join(COLUMNS))
        rows = list(reader)
    if not rows:
        fail("annual_checkouts.csv has no data rows")
    seen = set()
    for row in rows:
        try:
            year = int(row["year"])
            physical = float(row["physical_checkouts"])
            digital = float(row["digital_checkouts"])
            months = int(row["months_observed"])
            both = int(row["months_with_both_classes"])
        except (ValueError, TypeError) as error:
            fail(f"annual_checkouts.csv has a malformed numeric value: {error}")
        if year in seen or physical < 0 or digital < 0 or not (0 <= both <= months <= 12):
            fail(f"annual_checkouts.csv has impossible or duplicate values for year {year}")
        seen.add(year)


def check_monthly(path: Path) -> None:
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        if not set(MONTHLY_COLUMNS).issubset(reader.fieldnames or []):
            fail("monthly_comparison.csv is missing required columns: " + ", ".join(MONTHLY_COLUMNS))
        rows = list(reader)
    if not rows:
        fail("monthly_comparison.csv has no data rows")
    seen = set()
    for row in rows:
        try:
            key = (int(row["year"]), int(row["month"]))
            for name in ("physical_checkouts", "digital_checkouts"):
                if row[name] != "" and float(row[name]) < 0:
                    fail(f"monthly_comparison.csv has a negative {name} for {key}")
        except (ValueError, TypeError) as error:
            fail(f"monthly_comparison.csv has a malformed numeric value: {error}")
        if key in seen or not 1 <= key[1] <= 12 or row["both_classes_recorded"].lower() not in {"true", "false", "0", "1"}:
            fail(f"monthly_comparison.csv has an invalid or duplicate month: {key}")
        seen.add(key)


def main() -> None:
    require("AGENTS.md")
    require("project_notes.md")
    notebook = require("lab.ipynb")
    script = require("src/analyze_checkouts.py")
    inputs = [require("data/" + name) for name in INPUTS]
    check_notebook(notebook)
    before = {path.name: sha256(path.read_bytes()).hexdigest() for path in inputs}
    try:
        subprocess.run([sys.executable, str(script)], cwd=ROOT, check=True)
    except subprocess.CalledProcessError as error:
        fail(f"Analysis script failed with exit code {error.returncode}")
    after = {path.name: sha256(path.read_bytes()).hexdigest() for path in inputs}
    if before != after:
        fail("A frozen input changed during the analysis")
    for name in RESULTS:
        require("results/" + name)
    check_monthly(ROOT / "results/monthly_comparison.csv")
    check_table(ROOT / "results/annual_checkouts.csv")
    for name in ("checkout_trend.png", "coverage_and_share.png"):
        if (ROOT / "results" / name).read_bytes()[:8] != b"\x89PNG\r\n\x1a\n":
            fail(name + " is not a PNG")
    print("PASS: notebook responses, Mermaid diagram, project files, rerun, four results, and unchanged inputs passed structural checks.")
    print("Human review still required: prompt authenticity, source choice, diagram meaning, coverage, and visual claims.")


if __name__ == "__main__":
    main()
