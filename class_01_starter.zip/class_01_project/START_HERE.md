# Class 1: Investigate a checkout time series with a coding agent

This is one self-directed class. You will use a coding agent to inspect data, make project rules, draw a relationship diagram, build a repeatable analysis, and critique its visualizations. **The notebook is your guide and answer sheet; you must make the decisions and write the prompts.** Any editor/agent is suitable if it can read and edit this folder and run commands. A chat-only assistant without folder access cannot complete the file workflow.

## 1. Open and prepare the project

1. Unzip `class_01_starter.zip` and open the **whole `class_01_project` folder** in your editor. Keep the agent scoped to that folder. Do not edit `data/`.
2. Open a terminal in `class_01_project`. You need Python 3.11 or newer and JupyterLab 4.1 or newer for the Mermaid cell. If you already have pandas, matplotlib, and a compatible JupyterLab, use that environment. Otherwise create the environment **beside** this project, not inside the folder you will submit:

   macOS/Linux:

   ```sh
   python3 -m venv ../class_01_env
   source ../class_01_env/bin/activate
   python -m pip install -r requirements.txt
   python -m jupyter lab
   ```

   Windows Command Prompt:

   ```bat
   py -m venv ..\class_01_env
   ..\class_01_env\Scripts\activate.bat
   python -m pip install -r requirements.txt
   python -m jupyter lab
   ```

3. Open `lab.ipynb` in JupyterLab. Follow its six points in order. At each point, paste the **exact prompt** you sent, run the nearby preview cell to see the actual file/table/figure inside the notebook, and write your own analysis. Work with your coding agent in the editor, not only inside notebook cells. Ask it to show or explain file changes and commands before accepting them. Do not share credentials or secrets.

## 2. What you must produce

The finished `class_01_project` folder must contain:

| File | Purpose |
|---|---|
| `lab.ipynb` | Your six **exact prompts**, inline output previews, a rendered Mermaid relationship diagram in the marked Markdown cell, your analysis at every point, and your reflection. Do not substitute prompt summaries. |
| `AGENTS.md` | Your concise, inspected project rules. Check whether your chosen tool loads it automatically; if not, supply it explicitly or use its documented equivalent, and record what happened. |
| `project_notes.md` | Verified data facts, relationships, coverage cautions, your choices, and the next runnable command. |
| `src/analyze_checkouts.py` | The Python program that regenerates the four analysis results from `data/` without changing the source files. |
| `results/monthly_comparison.csv` | A previewable year/month table aligning recorded physical and digital values; missing class records remain blank. |
| `results/annual_checkouts.csv` | Annual recorded totals and the required coverage columns. |
| `results/checkout_trend.png` | A labeled physical/digital trend comparison. |
| `results/coverage_and_share.png` | A labeled coverage and/or digital-share visual with denominator and exclusions. |

Use the notebook for the detailed requirements and decisions. The two title CSVs are samples; do not use their sums as system-wide totals. Do not silently convert missing records to zero.

## 3. Check, then submit

From the `class_01_project` folder, run:

```sh
python src/analyze_checkouts.py
python checks/check_submission.py
```

On Windows, use `py` in place of `python` if that is how your environment is configured. Render and inspect your Mermaid Markdown cell in JupyterLab, and open both PNGs at normal size; do not rely only on a successful command. JupyterLab renders fenced Mermaid without a separate Mermaid CLI installation. The checker verifies file structure, the presence of Mermaid source, rerunnability, notebook completion, and that data were not changed **during its run**. It cannot judge whether your diagram is semantically correct, your prompt is authentic, or your interpretation is sound. Review those yourself.

Close JupyterLab and save the notebook. Compress the **entire `class_01_project` folder** into one ZIP (so `class_01_project` is the top-level folder inside). On macOS, right-click the folder and choose **Compress**. On Windows, right-click and choose **Send to → Compressed (zipped) folder** or **Compress to ZIP file**. Upload that single ZIP to Bloque Neón. Do **not** upload only the notebook. Exclude `class_01_env`, `.venv`, caches, credentials, and unrelated files. Keep `data/` and `checks/` in the ZIP.

## Sources and license

This lab adapts concepts from [Duke University's AI Accelerator](https://analytics-accelerator.colab.duke.edu/) under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). See `data/README.md` for the frozen data source and sampling notes. The exercise is tool-agnostic; project-rule support varies by agent.
